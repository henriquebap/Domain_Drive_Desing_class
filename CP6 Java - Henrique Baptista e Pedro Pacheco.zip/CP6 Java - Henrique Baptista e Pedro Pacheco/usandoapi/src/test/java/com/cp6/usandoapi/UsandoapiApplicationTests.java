package com.cp6.usandoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsandoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
