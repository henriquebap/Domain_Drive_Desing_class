package com.cp6.usandoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsandoapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsandoapiApplication.class, args);
	}

}
