package cp4;

interface Imprimir{
    void ExibirDados();
}
