package ddd;

public class testeOperacaoMatematica {
	
	public void realizaOperacao(OperacaoMatemaica op, double x, double y) {
		System.out.println(op.calcular(x, y));
	}
	
	public static void main(String[] args) {
		testeOperacaoMatematica teste = new testeOperacaoMatematica();
		
		teste.realizaOperacao(new Soma(), 10, 20);
		teste.realizaOperacao(new multiplica(), 10, 10);
	}
}
