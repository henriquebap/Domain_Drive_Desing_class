package ddd;

public class Soma extends OperacaoMatemaica{
	//Sobre escrita do metodo calcular
	public double calcular(double x, double y) {
		return x+ y; 
	}
}
