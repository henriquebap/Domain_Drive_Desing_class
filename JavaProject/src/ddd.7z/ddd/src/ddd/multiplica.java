package ddd;

public class multiplica extends OperacaoMatemaica {
	//Sobe escrita do metodo calcular
	
	public double calcular(double x, double y) {
		return x * y;
	}
}
