package ddd;

public class OperacaoMatemaica {
	public double calcular(double x, double y) {
		return 0;
	}
	
	
}
