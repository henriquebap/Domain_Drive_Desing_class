package Aula_Polimorfismo;

public class ContaCorrente implements Conta{

	
	private double saldo;
	private double taxaOp = 0.5;
	
	@Override
	public void depositar(double valor) {
		this.saldo += valor - (valor*taxaOp);
	}

	@Override
	public void sacar(double valor) {
		this.saldo -= valor;
		
	}

	@Override
	public double getSaldo() {
	
		return this.saldo;	
	
	}

}
