package Aula_Polimorfismo;

public abstract class ContaImpl {
	
	private double saldo;

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public abstract void imprimirExtrato();
	
}
