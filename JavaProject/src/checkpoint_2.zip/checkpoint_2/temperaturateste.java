package checkpoint_2;

// Henrique Oliveira Baptista Rm 97796
public class temperaturateste {
    public static void main(String[] args) {
        //6) Função principal para testar o programa
        GerenciadorTemp gt = new GerenciadorTemp();
        gt.SolicitaPeriodoS();
        gt.coletarTemperaturas();  

    }
    
}
