package checkpoint_2;

public class Periodo {
    private int semana;
    private int dia;
    
    public Periodo(int semana, int dia){
        this.semana = semana;
        this.dia = dia;
    }

    public int getSemana() {
        return this.semana;
    }

    public void setSemana(int semana) {
        this.semana = semana;
    }

    public int getDia() {
        return this.dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }
    
    
}
